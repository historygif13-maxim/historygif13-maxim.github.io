from steam_bot.client import run_bot
run_bot()
