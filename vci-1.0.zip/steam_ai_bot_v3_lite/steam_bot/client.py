import asyncio,steam
from config import config
from commands.router import command_router
class SteamAIBot(steam.Client):
 async def on_ready(self):print('Steam AI Bot V3 Lite ONLINE:',self.user)
 async def on_message(self,message:steam.Message):
  if message.author==self.user:return
  t=(message.content or '').strip()
  if not t:return
  a=await asyncio.to_thread(command_router.handle,str(message.author.id),t)
  for i in range(0,len(str(a)),config.MAX_MESSAGE_LENGTH):await message.channel.send(str(a)[i:i+config.MAX_MESSAGE_LENGTH])
def run_bot():
 if not config.STEAM_USERNAME or not config.STEAM_PASSWORD:raise RuntimeError('Заполни .env')
 SteamAIBot().run(config.STEAM_USERNAME,config.STEAM_PASSWORD)
