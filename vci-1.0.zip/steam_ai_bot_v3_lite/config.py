import os
from dotenv import load_dotenv
load_dotenv()
class Config:
 STEAM_USERNAME=os.getenv('STEAM_USERNAME','').strip();STEAM_PASSWORD=os.getenv('STEAM_PASSWORD','').strip();OLLAMA_HOST=os.getenv('OLLAMA_HOST','http://127.0.0.1:11434');DEFAULT_MODEL=os.getenv('DEFAULT_MODEL','qwen2.5:3b');DATABASE_PATH=os.getenv('DATABASE_PATH','data/bot.db');MAX_MESSAGE_LENGTH=int(os.getenv('MAX_MESSAGE_LENGTH','3500'))
config=Config()
