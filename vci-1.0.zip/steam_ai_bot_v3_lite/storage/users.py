import os,sqlite3
from config import config
os.makedirs(os.path.dirname(config.DATABASE_PATH) or '.',exist_ok=True)
class Users:
 def __init__(self):
  self.db=sqlite3.connect(config.DATABASE_PATH,check_same_thread=False);self.db.execute('CREATE TABLE IF NOT EXISTS users (steam_id TEXT PRIMARY KEY, model TEXT)');self.db.commit()
 def get(self,s):
  r=self.db.execute('SELECT model FROM users WHERE steam_id=?',(str(s),)).fetchone();return r[0] if r else config.DEFAULT_MODEL
 def set(self,s,m):self.db.execute('INSERT INTO users VALUES (?,?) ON CONFLICT(steam_id) DO UPDATE SET model=excluded.model',(str(s),m));self.db.commit()
 def reset(self,s):self.db.execute('DELETE FROM users WHERE steam_id=?',(str(s),));self.db.commit()
users=Users()
