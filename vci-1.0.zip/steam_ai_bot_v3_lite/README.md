# Steam AI Bot V3 Lite

Commands: /models, /model NAME, /current, /reset, /help.
Each Steam user has their own selected Ollama model.
Install Python 3.12 and Ollama, pull a model, run install.bat, fill .env, then run.bat.
