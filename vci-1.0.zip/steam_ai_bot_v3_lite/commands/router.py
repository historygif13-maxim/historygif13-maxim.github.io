from ai.ollama_ai import models,chat
from storage.users import users
class Router:
 def handle(self,s,msg):
  msg=(msg or '').strip();cmd,_,arg=msg.partition(' ');arg=arg.strip()
  if cmd=='/help':return '🤖 /models\n/model <имя>\n/current\n/reset\n\nИли просто напиши сообщение.'
  if cmd=='/models':
   try:
    m=models();return '📋 Модели:\n'+('\n'.join('• '+x for x in m) if m else 'Нет моделей')
   except Exception as e:return '❌ Ollama error: '+str(e)
  if cmd=='/current':return '🤖 Текущая модель: '+users.get(s)
  if cmd=='/model':
   if not arg:return '❌ Использование: /model имя'
   try:
    if arg not in models():return '❌ Нет такой модели. Используй /models'
    users.set(s,arg);return '✅ Выбрана: '+arg
   except Exception as e:return '❌ Ollama error: '+str(e)
  if cmd=='/reset':users.reset(s);return '✅ Модель: '+users.get(s)
  try:return chat(users.get(s),msg)
  except Exception as e:return '❌ AI error: '+str(e)
command_router=Router()
