import ollama
from config import config
def c():return ollama.Client(host=config.OLLAMA_HOST)
def models():
 r=c().list();x=r.get('models',[]) if isinstance(r,dict) else r.models;return [a.get('model') if isinstance(a,dict) else a.model for a in x]
def chat(m,p):
 r=c().chat(model=m,messages=[{'role':'system','content':'Ты полезный ассистент Steam. Отвечай по-русски.'},{'role':'user','content':p}]);return r['message']['content'] if isinstance(r,dict) else r.message.content
